//Alessandro Morsella 40096192
//Gechen Ma 40026175
//Assignment 5, Question 2
#include "DataStorage.h"
#include<fstream>


DataStorage::DataStorage() 
{
	iptr = 0;
	cptr = 0;
	fptr = 0;
}


DataStorage::~DataStorage()
{
}

void DataStorage::setsize(int s)
{
	size = s;
}

int DataStorage::getsize()
{
	return size;
}

void DataStorage::setiptr(int *i)
{
	*i = *iptr;
}

int* DataStorage::getiptr()
{
	return iptr;
}

void DataStorage::setfptr(float *f)
{
	*f = *fptr;
}

float* DataStorage::getfptr() const
{
	return fptr;
}

void DataStorage::setcptr(char *c)
{
	*c = *cptr;
}

char* DataStorage::getcptr() const
{
	return cptr;
}

void DataStorage::setdatatype(string d)
{
	d = datatype;
}

string DataStorage::getdatatype()
{
	return datatype;
}

void DataStorage::readdata(DataStorage *dsPtr, int n)
{
	ifstream in("config.dat");
	for (int i = 0; i < n; i++)
	{
		cin >> datatype >> size;
		if (datatype == "int")
		{
			iptr = new int[size];
			for (int j = 0; j < size; j++)
			{
				cin >> iptr[j];
				dsPtr[j].setiptr(iptr);
			}
		}
		else if (datatype == "float")
		{
			fptr = new float[size];
			for (int k = 0; k < size; k++)
			{
				cin >> fptr[k];
				dsPtr[k].setfptr(fptr);
			}
		}
		else if (datatype == "char")
		{
			cptr = new char[size];
			for (int l = 0; l < size; l++)
			{
				cin >> cptr[l];
				dsPtr[l].setcptr(cptr);
			}
		}
	}
}


void DataStorage::printdata(DataStorage *dsPtr, int n)
{

	for (int i = 0; i < size; i++)
	{
		cout << "Record " << (i + 1) << ": ";
		if (datatype == "int")
		{
			iptr = dsPtr[i].getiptr();
			for (int j = 0; j < dsPtr[i].getsize(); j++) {
				cout << iptr[j] << " ";
			}
		}
		else if (dsPtr[i].getdatatype() == "float")
		{
			fptr = dsPtr[i].getfptr();
			for (int j = 0; j < dsPtr[i].getsize(); j++) {
				cout << fptr[j] << " ";
			}
		}
		else
		{
			cptr = dsPtr[i].getcptr();
			for (int j = 0; j < dsPtr[i].getsize(); j++)
			{
				cout << cptr[j] << " ";
			}

		}
	}
}

