//Alessandro Morsella 40096192
//Gechen Ma 40026175
//Assignment 5, Question 2
#include<string>
#include<iostream>
#ifndef DATASTORAGE_H
#define DATASTORAGE_H
using namespace std;

class DataStorage
{
	int *iptr;
	float *fptr;
	char *cptr;
	int size;
	string datatype;
public:
	DataStorage();
	int getsize();
	void setsize(int);
	string getdatatype();
	void setdatatype(string);
	int *getiptr();
	void setiptr(int *i);
	float *getfptr() const;
	void setfptr(float *f);
	char *getcptr() const;
	void setcptr(char *c);
	void readdata(DataStorage *dsPtr, int);
	void printdata(DataStorage *dsPtr, int);
	~DataStorage();
};
#endif // !DATASTORAGE_H