//Alessandro Morsella 40096192
//Gechen Ma 40026175
//Assignment 5, Question 1
#include <iostream>
#include "Node.h"
using namespace std;

Node::Node() {

	element = 0;
	next = NULL;

}


Node::Node(const Node&n) {

	element = n.element;
	next = n.next;

}

void Node::setelem(int ele) {

	element = ele;

}

void Node::setnext(Node *nxt) {

	next = nxt;

}

int Node::getelem() {

	return element;

}

Node Node::getnext() {

	return *next;
}

Node::~Node() {

}
