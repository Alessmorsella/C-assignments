//Alessandro Morsella 40096192
//Gechen Ma 40026175
//Assignment 5, Question 1
#include <iostream>
#include "LinkedList.h"
#include "Node.h"
using namespace std;


int main() {

	
	LinkedList L;

	L.add(45);
	L.add(21);
	L.add(32);
	L.add(12);
	L.add(76);
	L.add(98);
	L.remove(12);
	L.addpos(54, 3);
	L.delpos(4);
	L.searchpos(2);
	
try {

	L.search(32);
	if (L.search(32) == false)
		throw "Not found";
	cout << "Found" << endl;

}
catch (char*str) {
	cout << str << endl;
}

	cout << L << endl;

	
	system("pause");
	return 0;
}