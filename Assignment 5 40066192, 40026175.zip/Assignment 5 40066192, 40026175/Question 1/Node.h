//Alessandro Morsella 40096192
//Gechen Ma 40026175
//Assignment 5, Question 1
#include<iostream>
#ifndef NODE_H
#define NODE_H

using namespace std;

class Node {

public:
	int element;
	Node * next;
	Node();

	Node(const Node&n);

	void setelem(int ele);

	void setnext(Node *nxt);

	int getelem();
	Node getnext();
	~Node();
};
#endif // !NODE_H
