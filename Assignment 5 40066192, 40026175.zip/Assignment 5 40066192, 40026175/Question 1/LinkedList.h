//Alessandro Morsella 40096192
//Gechen Ma 40026175
//Assignment 5, Question 1
#include <iostream>
#include "Node.h"
#ifndef LINKEDLIST_H
#define LINKEDLIST_H

class LinkedList {

private:

	Node *head;
	Node *tail;

public:

	LinkedList();
	~LinkedList();
	bool search(int ele);
	void add(int ele);
	void remove(int ele);
	void addpos(int ele, int pos);
	void delpos(int pos);
	void searchpos(int pos);
	friend ostream &operator <<(ostream&out, const LinkedList&l) {

		Node *n;
		for (n = l.head; n != 0; n = n->next)
			out << n->element<<" ";
		out << endl;
		return out;
	};


};

#endif // !LINKEDLIST_H
