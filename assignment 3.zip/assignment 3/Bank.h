//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include<string>
#include<iostream>
#include "Branch.h"
#include "customer.h"
#ifndef BANK_H
#define BANK_H
using namespace std;

class Bank
{private:
	int Bankid;
	string name;
	string address;
	string telephone_number;
	int Num_of_bracnch;
	Branch* B;
	

public:
	Bank();
	Bank(int, string, string, string, int);
	string getName();
	string getAddress();
	string getTelephoneNumber();
	int getNumberOfBramch();
	int getId();
	void  Add_branch(const Branch& b);
	void delete_branch(int);
	void setBranch(Branch&);
	Branch* getBranch();
	void ListAllBranch();
	void list_account(int);
	void list_customer(int);
	void printInfoOfBranch(int);
	void printInfoOfAccount(int);
	void printInfoOfCustomer(int);
	~Bank();
};
#endif