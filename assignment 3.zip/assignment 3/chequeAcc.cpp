//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include "chequeAcc.h"
#include <iostream>
using namespace std;

chequeAcc::chequeAcc()
{
	acctype = 1;
}


chequeAcc::~chequeAcc()
{
}
chequeAcc::chequeAcc(bool pri, float over)
{
	chequePrivilege = pri;
	overdraftlimit = over;
}

void chequeAcc::setChequePri(bool chequepri)
{
	chequePrivilege = chequepri;
}

bool chequeAcc::getChequePri()
{
	return chequePrivilege;
}

void chequeAcc::setoverdraft(float limit)
{
	overdraftlimit = limit;
}
float chequeAcc::getoverdraft()
{
	return overdraftlimit;
}