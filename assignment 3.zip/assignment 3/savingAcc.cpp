//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include "savingAcc.h"
#include<iostream>
using namespace std;
savingAcc::savingAcc()
{
	Max_num_transaction = 0;
	interest_rate = 0.0;
	acctype = 1;
}



savingAcc::~savingAcc()
{
}

savingAcc::savingAcc(int max, double interest)
{
	Max_num_transaction = max;
	interest_rate = interest;
}
int savingAcc::getMaxNumTransaction()
{
	return Max_num_transaction;
}
double savingAcc::getInterestRate()
{
	return interest_rate;
}

void savingAcc::print()
{
	Account::print();
	cout << "the max_numtransaction is " << Max_num_transaction << endl;
	cout << "the interest rate" << interest_rate << endl;
}