//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include <iostream>
#include "Account.h"
#ifndef BRANCH_H
#define BRANCH_H

class Branch
{private:
	int BranchId;
	string address;
	string telephone_number;
	int Num_of_accounts;
	Account* A;
public:
	Branch();
	~Branch();
	Branch(int, string, string, int);
	string getAddres();
	string getTelephoneNumber();
	int getNumOfAccount();
	Account* getAccount();

	int getId();
	void add_account(const Account& A);
	void delete_accounts(int);
	void ListAllAccount();
	void print_given_account(int);
	void List_customer();
	bool isBranchCustomer(int);



};
#endif