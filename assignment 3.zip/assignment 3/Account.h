//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include <iostream>
#ifndef ACCOUNT_H
#define ACCOUNT_H
#include"customer.h"
using namespace std;
class Account
{protected:
	int AccountNumber;
	double Balance;
	int Transaction_fee;
	customer C;

	int acctype;

public:
	Account();
	int getAccountNum() const;
	~Account();
	Account(int, double);
	double getBalance() const;
	void Addowner(const customer&);
	void printOwner();
	int getAccType() const;
	customer getowner() const;
	void deleteowner();
	virtual void print();

};

#endif