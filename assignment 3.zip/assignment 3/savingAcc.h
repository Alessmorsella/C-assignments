//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include <iostream>
#include"Account.h"
#ifndef SAVINGACC_H
#define SAVINGACC_H
using namespace std;

class savingAcc :public Account
{private:

	int Max_num_transaction;
	double interest_rate;
	int acctype;

public:
	savingAcc();
	~savingAcc();
	savingAcc(int, double);
	int getMaxNumTransaction();
	double getInterestRate();
	void print();
};
#endif // !SAVINGACC_H