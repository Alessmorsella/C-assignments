//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include "customer.h"
#include"Account.h"
#include<iostream>

using namespace std;

customer::customer()
{
	customerId = "";
	customerFirstName = "";
	customerLastName = "";
	address = "";
	telephone_number = "";
	email = "";
	num_of_acc_of_customer = 0;
	a = new Account[10];

}


customer::~customer()
{
}


customer::customer(string id, string Cf, string CL, string add, string tele, string e, int Num)
{
	customerId = id;
	customerFirstName = Cf;
	customerLastName = CL;
	address = add;
	telephone_number = tele;
	email = e;
	num_of_acc_of_customer = Num;
}

void customer::setId(string id)
{
	customerId = id;
}

string customer::getId()
{
	return customerId;
}

string customer::getCustomerFirstname()
{
	return customerFirstName;
}

string customer::getCustomerLastName()
{
	return customerLastName;
}

string customer::getAddress()
{
	return address;
}

string customer::getEmail()
{
	return email;
}

int customer::getNumOfACCofCus()
{
	return num_of_acc_of_customer;
}
string customer::getTelephoneNumber()
{
	return telephone_number;
}

void customer::AddAccount(const Account& a1)
{
	if (num_of_acc_of_customer < 10)
	{
		a[num_of_acc_of_customer] = a1;
		num_of_acc_of_customer++;
	}

	else
		cout << "the account are exceed, can't add acount" << endl;

}

void customer::DeleteAccount(int accNum)
{
	bool find = false;

	for (int i = 0; i < num_of_acc_of_customer; i++)
	{
		if (a[i].getAccountNum == accNum)
		{
			for (int j = i; j < num_of_acc_of_customer - 1; j++)
			{
				a[j] = a[j + 1];
			}
			num_of_acc_of_customer--;
			find = true;
			break;
		}

	}
	if (find = true)
	{
		cout << "the account has been found";
	}
	else
	{
		cout << "the account can not be found" << endl;
	}
}

void customer::ListAllAccount()
{
	for (int i = 0; i < num_of_acc_of_customer; i++)
	{
		cout << "Account" << a[i].getAccountNum() << endl;
	}
}

void customer::ListAllChequingAcc()
{
	for (int i = 0; i < num_of_acc_of_customer; i++)
	{
		if (a[i].getAccType() == 1)
			cout << "chequeing account" << a[i].getAccountNum() << endl;
	}
}

void customer::ListAllSavingAcc()
{
	for (int i = 0; i < num_of_acc_of_customer; i++)
	{
		if (a[i].getAccType() == 0)
			cout << "saving account" << a[i].getAccountNum() << endl;
	}
}
void customer::print()
{
	cout << "the customer id is" << customerId << endl;
	cout << "the customer first name is " << customerFirstName << endl;
	cout << "the customer last name is " << customerLastName << endl;
	cout << "the customer address is " << address << endl;
	cout << "the customer telephone number is" << telephone_number << endl;
	cout << "the customer email is " << email << endl;
}