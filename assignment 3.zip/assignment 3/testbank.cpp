//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192

#include <iostream>
#include "Account.h"
#include "Bank.h"
#include "Branch.h"
#include "chequeAcc.h"
#include "customer.h"
#include "savingAcc.h"

using namespace std;

int main() {

	Bank b1(1234, "National Bank", "12345 Ste-Catherine", "514-123-4567", 1245);
	Branch br1(3235, "12345 st laurent", "514-234-3456", 12);
	Account a1(1234, 1234.89);
	customer c1("1234", "Daniel", "Jones", "1234 St-Laurent", "514-234-4567", "danieljones@gmail.com", 3);
	savingAcc s1(1234, 1246.65);
	chequeAcc ch1(true, 1234.56);

	b1.Add_branch(br1);
	br1.add_account(a1);
	a1.Addowner(c1);
	c1.AddAccount(a1);
	c1.AddAccount(ch1);
	c1.AddAccount(s1);


	b1.ListAllBranch();
	b1.printInfoOfAccount(1234);
	br1.isBranchCustomer(1234);
	br1.ListAllAccount();
	br1.List_customer();






	system("pause");
	return 0;
}