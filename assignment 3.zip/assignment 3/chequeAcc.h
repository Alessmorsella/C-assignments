//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include <iostream>
#include"Account.h"
#ifndef CHEQUEACC_H
#define CHEQUEACC


class chequeAcc :public Account
{private:
	bool chequePrivilege;
	float overdraftlimit;
	int acctype;

public:
	chequeAcc();
	~chequeAcc();
	chequeAcc(bool, float);
	void setChequePri(bool);
	bool getChequePri();
	float getoverdraft();
	void setoverdraft(float);

};
#endif // !CHEQUEACC_H