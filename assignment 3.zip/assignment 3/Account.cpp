//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include "Account.h"
#include<iostream>

using namespace std;


Account::Account()
{
	AccountNumber = 0;
	Balance = 0.0;
	Transaction_fee = 0;


}


Account::~Account()
{
}

int Account::getAccountNum() const
{
	return AccountNumber;
}
int  Account::getAccType() const
{
	return acctype;
}

Account::Account(int AC, double B)
{
	AccountNumber = AC;
	Balance = B;
}
double Account::getBalance() const
{
	return Balance;
}

void Account::Addowner(const customer& c)
{
	C = c;
}

customer Account::getowner() const
{
	return C;
}

void Account::deleteowner()
{
	delete C;
}
void Account::printOwner()
{

	cout << "the information of owner is :" << endl;
	C.print();
}

 void  Account::print()
{
	cout << "the account id is " << AccountNumber << endl;
	cout << "the account balance is " << Balance << endl;
	cout << "the account trasaction fee is " << Transaction_fee << endl;
	cout << "the owner's name is " << C.getCustomerFirstname() << " " << C.getCustomerLastName() << endl;
}