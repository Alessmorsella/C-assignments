//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include <iostream>
#include<string>
#ifndef CUSTOMER_H
#define CUSTOMER_H
using namespace std;
class customer
{private:
	string customerId;
	string customerFirstName;
	string customerLastName;
	string address;
	string telephone_number;
	string email;
	int num_of_acc_of_customer;
	Account* a;
public:
	customer();
	~customer();
	customer(string, string, string, string, string, string, int);
	void setId(string id);
	string getId();
	string getCustomerFirstname();
	string getCustomerLastName();
	string getAddress();
	string getTelephoneNumber();
	string getEmail();
	int getNumOfACCofCus();
	void  AddAccount(const Account&);
	void DeleteAccount(int accNum);
	void ListAllAccount();
	void ListAllChequingAcc();
	void ListAllSavingAcc();
	void print();
};
#endif // !ACCOUNT_H
