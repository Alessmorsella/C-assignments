//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include "Bank.h"
#include <iostream>
using namespace std;

Bank::Bank()
{
	Bankid = 0;
	name = "";
	address = "";
	telephone_number = "";
	Num_of_bracnch = 0;
	B = new Branch[10];
}


Bank::~Bank()
{
}

Bank::Bank(int id, string na, string add, string tele, int num)
{
	Bankid = id;
	name = na;
	address = add;
	telephone_number = tele;
	Num_of_bracnch = num;

}

int Bank::getId()
{
	return Bankid;
}


string Bank::getName()
{
	return name;
}

string Bank::getAddress()
{
	return address;
}


string Bank::getTelephoneNumber()
{
	return telephone_number;
}

int Bank::getNumberOfBramch()
{
	return Num_of_bracnch;
}

void Bank::setBranch(Branch &b)
{
	B = b;
}

Branch* Bank::getBranch()
{
	return B;
}

void Bank::Add_branch(const Branch& b)
{
	if (Num_of_bracnch < 10)
	{
		B[Num_of_bracnch] = b;
		Num_of_bracnch++;
	}
	else
		cout << "can't add branch" << endl;
}

void Bank::delete_branch(int branchid)
{
	bool find = false;

	for (int i = 0; i < Num_of_bracnch; i++)
	{
		if (B[i].getId() == branchid)
		{
			for (int j = i; j <Num_of_bracnch - 1; j++)
			{
				B[j] = B[j + 1];
			}
			Num_of_bracnch--;
			find = true;
			break;
		}

	}
	if (find = true)
	{
		cout << "the Branch has been deleted";
	}
	else
	{
		cout << "the branch can not be found" << endl;
	}
}

void Bank::ListAllBranch()
{
	for (int i = 0; i <Num_of_bracnch; i++)
	{
		cout << "Branch" << B[i].getId() << endl;
	}
}


void Bank::list_account(int branchid)
{
	bool find = false;

	for (int i = 0; i < Num_of_bracnch; i++)
	{
		if (B[i].getId() == branchid)
		{
			B[i].ListAllAccount();
			find = true;
			break;
		}

	}
	if (!find)
	{
		cout << "the branch can not be found" << endl;
	}
}

void Bank::list_customer(int branchid)
{
	bool find = false;

	for (int i = 0; i < Num_of_bracnch; i++)
	{
		if (B[i].getId() == branchid)
		{
			B[i].List_customer();
			find = true;
			break;
		}

	}
	if (!find)
	{
		cout << "the branch can not be found" << endl;
	}
}

void Bank::printInfoOfBranch(int id)
{
	for (int i = 0; i < Num_of_bracnch; i++)
	{
		if (B[i].getId() == id)
		{
			cout << "the branch id is" << B[i].getId() << endl;
			cout << "the brach address is" << B[i].getAddres() << endl;
			cout << "the branch telephone number is" << B[i].getTelephoneNumber() << endl;
		}
	}
}
void Bank::printInfoOfAccount(int id)
{
	for (int i = 0; i < Num_of_bracnch; i++)
	{
		for (int j = 0; j < B[i].getNumOfAccount(); j++)
		{
			B[j].print_given_account(id);
		}
	}
}

void Bank::printInfoOfCustomer(int id)
{for (int i = 0; i < Num_of_bracnch; i++)
{
	if (B[i].isBranchCustomer(id)==true)
	{
		B[i].List_customer();
	
	}
}
}