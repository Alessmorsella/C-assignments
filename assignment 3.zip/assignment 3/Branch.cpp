//COEN 244 Assignment 3
//Gechen Ma 40026175
//Alessandro Morsella 40096192
#include "Branch.h"
#include"Account.h"
#include <iostream>
using namespace std;

Branch::Branch()
{
	BranchId = 0;
	address = "";
	telephone_number = "";
	Num_of_accounts = 0;
	A = new Account[20];
}


Branch::~Branch()
{
}


Branch::Branch(int idB, string addB, string teleB, int numA)
{
	BranchId = idB;
	address = addB;
	telephone_number = teleB;
	Num_of_accounts = numA;
}


int Branch::getId()
{
	return BranchId;
}

string Branch::getAddres()
{
	return address;
}

string Branch::getTelephoneNumber()
{
	return telephone_number;

}


int Branch::getNumOfAccount()
{
	return Num_of_accounts;
}

Account* Branch::getAccount()
{
	return A;
}

void Branch::add_account(const Account& newacc)
{

	if (Num_of_accounts < 10)
	{
		A[Num_of_accounts] = newacc;
		Num_of_accounts++;
	}

	else
		cout << "the account are exceed, can't add acount" << endl;
}

void Branch::delete_accounts(int accNum)
{
	bool find = false;

	for (int i = 0; i < Num_of_accounts; i++)
	{
		if (A[i].getAccountNum == accNum)
		{
			for (int j = i; j < Num_of_accounts - 1; j++)
			{
				A[j] = A[j + 1];
			}
			Num_of_accounts--;
			find = true;
			break;
		}

	}
	if (find = true)
	{
		cout << "the account has been deleted";
	}
	else
	{
		cout << "the account can not be found" << endl;
	}
}

void Branch::ListAllAccount()
{
	for (int i = 0; i < Num_of_accounts; i++)
	{
		cout << "Account" << A[i].getAccountNum() << endl;
	}
}

void Branch::print_given_account(int accNum)
{
	bool find = false;

	for (int i = 0; i < Num_of_accounts; i++)
	{
		if (A[i].getAccountNum == accNum)
		{
			A[i].print();
			find = true;
			break;
		}

	}


	if (!find)
	{
		cout << "the account can not be found" << endl;
	}
}

void Branch::List_customer()
{
	for (int i = 0; i < Num_of_accounts; i++)
	{
		cout << "Account" << A[i].getowner().getCustomerFirstname() << A[i].getowner().getCustomerLastName() << endl;
	}
}


bool Branch::isBranchCustomer(int id)
{
	for (int i = 0; i < Num_of_accounts; i++)
	{
		if (A[i].getowner().getId() == id)
		{
			return true;
		}
	}
	return false;
}
