//Alessandro Morsella 40096192
//Gechen Ma 40026175
//Assignment 5, Question 1
#include <iostream>
#include "LinkedList.h"
using namespace std;

LinkedList::LinkedList() {
	head = NULL;
	tail = NULL;
}

LinkedList::~LinkedList() {

}

void LinkedList::add(int ele) {

	Node *temp = new Node;
	temp->element = ele;
	temp->next = NULL;

	if (head == NULL) {
		head = temp;
		tail = temp;
	}
	else {

		tail->next = temp;
		tail = tail->next;
	}


}

bool LinkedList::search(int ele) {

	Node *temp = new Node;
	temp = head;
	while (temp != NULL)
	{
		if (temp->element == ele)
			return true;
		temp = temp->next;
	}
	return false;
}

void LinkedList::remove(int ele) {

	Node *temp = new Node;
	Node *prev = new Node;

		if (head == NULL)
			return;



		if (head->element == ele)
		{
			temp = head;
			head = head->next;
			delete temp;
		}
		else {
			temp = head;
			while (temp != NULL&&temp->element != ele)
			{
				prev = temp;
				temp = temp->next;

			}

			if (temp != NULL) {
				prev->next = temp->next;


				delete temp;

			}
		}
	}



void LinkedList::addpos(int ele, int pos) {

	Node *temp = new Node;
	Node *prev = new Node;
	Node *curr = new Node;
	curr = head;
	for(int i=1;i<pos;i++)

	{
		prev = curr;
		curr = curr->next;
	}
	temp->element = ele;
	prev->next = temp;
	temp->next = curr;

}

void LinkedList::delpos(int pos) {

	Node *curr = new Node;
	Node *prev = new Node;

	curr = head;
	for (int i = 1; i<pos; i++)

	{
		prev = curr;
		curr = curr->next;
	}
	prev->next = curr->next;
}

void LinkedList::searchpos(int pos) {
	Node *curr = new Node;
	Node *prev = new Node;

	curr = head;
	for (int i = 1; i < pos; i++)

	{
		prev = curr;
		curr = curr->next;
	}
	cout << "The value stored in node " << pos << " is " << curr->element << endl;
}
