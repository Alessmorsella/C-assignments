//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include <iostream>
#include "vector.h"
using namespace std;

int main() {

	Vector v1(12, 23, 34);
	Vector v2(21, 34, 12);
	Vector v3;
	Vector v4;
	

	v1 == v2;
	v1 != v2;

	v3=v1 + v2;
	v4=v1*v2;
	v1 ^ v2;

	cout << v3<<endl;
	cout << v4<<endl;




	system("pause");
	return 0;
}