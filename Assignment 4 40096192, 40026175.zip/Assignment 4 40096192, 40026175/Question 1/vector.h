//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include <iostream>
#ifndef VECTOR_H
#define VECTOR_H

using namespace std;
class Vector {

public:
	Vector();
	Vector(int x1, int y1, int z1);
	int getx();
	int gety();
	int getz();
	Vector operator+(const Vector&);
	Vector operator*(const Vector&);
	friend ostream &operator << (ostream& out, const Vector&v) {
		out << v.x << "i" << "+" << v.y << "j" << "+" << v.z << "k";
		return out;
	};
	friend istream & operator >> (istream& in, Vector& v) {
		in >> v.x >> v.y >> v.z;
		return in;
	};
	void operator ==(const Vector&);
	void operator !=(const Vector&);
	void operator ^(const Vector&);
private:

	int x, y, z;
};

#endif // !VECTOR_H
