//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include <iostream>
#include "vector.h"
using namespace std;

Vector::Vector() {
	x = 0;
	y = 0;
	z = 0;
}

Vector::Vector(int x1, int y1, int z1){

	x = x1;
	y = y1;
	z = z1;
}

int Vector::getx() {

	return x;

}

int Vector::gety() {

	return y;

}

int Vector::getz() {

	return z;

}

Vector Vector::operator+(const Vector& v) {

	Vector vector1;
	vector1.x = this->x + v.x;
	vector1.y = this->y + v.y;
	vector1.z = this->z + v.z;
	return vector1;
}

void Vector::operator==(const Vector& v) {
	Vector vector2;
	if (v.x == this->x&&v.y == this->y&&v.z == this->z) {
		cout << "both vectors are equal" << endl;
	}
	else {
		cout << "The vectors are not equal" << endl;
	}

}

void Vector::operator!=(const Vector& v) {
	Vector vector3;
	if (!(v.x == this->x && v.y == this->y && v.z == this->z)) {
		cout << "both vectors are not equal" << endl;
	}
	else {
		cout << "both vectors are equal" << endl;
	}

	
}

Vector Vector::operator*(const Vector& v) {

	Vector vector4;
	vector4.x = this->x * v.x;
	vector4.y = this->y * v.y;
	vector4.z = this->z * v.z;
	return vector4;

}


void Vector::operator^(const Vector& v)
{
	Vector vector5;
	vector5.x = x*v.x;
	vector5.y = y*v.y;
	vector5.z = z*v.z;
	cout << vector5.x + vector5.y + vector5.z << endl;
}

