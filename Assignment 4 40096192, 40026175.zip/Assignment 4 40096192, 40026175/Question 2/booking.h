//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include <iostream>
#include <string>
#include "passenger.h"
#ifndef BOOKING_H
#define BOOKING_H

using namespace std;

class Booking {
private:

	int bookingID;
	passenger p;
	string seat;


public:
	int globalBookingID; // Will be used to set booking id incrementally 
	Booking();
	Booking(const passenger& p1, string s1);

	/* Accessing Methods */
	int getBookingID() const;
	passenger getPassenger() const;
	string getSeat() const;
	void setSeat(string s1);
	void print();
};
#endif // !BOOKING_H