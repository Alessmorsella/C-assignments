//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include"person.h"
#include<iostream>

#ifndef EMPLOYEE_H
#define EMPLOYEE_H
using namespace std;

class employee:public Person
{
	string jobfunction;
public:
	employee();
	employee(string);
	string getJobfunction();
	~employee();
};

#endif // !EMPLOYEE_H