//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include"person.h"
#include<string>
#include<iostream>
using namespace std;
#ifndef PASSENGER_H
#define PASSENGER_H


class passenger :public Person
{	private:

	string frequentFlyPlan;

public:
	passenger();
	passenger(string);
	string getFrequenFlyPlan()const;

	~passenger();
};

#endif // !PASSENGER_H