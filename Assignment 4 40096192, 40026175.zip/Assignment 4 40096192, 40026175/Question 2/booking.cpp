//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include "booking.h"
#include <iostream>
#include <string>
#include "passenger.h"
using namespace std;

Booking::Booking() {}
Booking::Booking(const passenger& p1, string s1) : p(p1), seat(s1) {
	globalBookingID++;
	bookingID = globalBookingID;
}

/* Accessing Methods */
int Booking::getBookingID() const {
	return bookingID;
}

passenger Booking::getPassenger() const {
	return p;
}

string Booking::getSeat() const {
	return seat;
}

void Booking::setSeat(string s1) {
	seat = s1;
}

void Booking::print() {
	cout << "Booking: " << bookingID << endl;
	cout << "Passenger Info:" << endl;
	p.print();
	cout << "Flight Info:" << endl;
	cout << "Seat: " << seat << endl;
}

