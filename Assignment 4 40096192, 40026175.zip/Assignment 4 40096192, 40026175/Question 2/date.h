//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include <iostream>
#ifndef DATE_H
#define DATE_H
using namespace std;

class Date {
private:
	int day;
	int month;
	int year;

public:
	Date() {}
	Date(int d, int m, int y) { day = d; month = m; year = y; }
	void setDate(int d, int m, int y) { day = d; month = m; year = y; }
	int getDay() const { return day; }
	int getMonth() const { return month; }
	int getYear() const { return year; }
	void print() const { cout << day << "-" << month << "-" << year << endl; }
};

#endif // !DATE_H