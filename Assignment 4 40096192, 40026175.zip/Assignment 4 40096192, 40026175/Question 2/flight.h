//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include <iostream>
#include <string>
#include "time.h"
#include "date.h"
#include "employee.h"
#include "booking.h"
#ifndef FLIGHT_H
#define FLIGHT_H


using namespace std;

class Flight {
private:
	int flightID;
	Time departureTime;
	Date departureDate;
	Time arrivalTime;
	Date arrivalDate;
	string departureCity;
	string arrivalCity;
	employee *e;
	Booking *b;
	int nbbookings;
	int nbemployees;
	
public:
	Flight();
	Flight(int id1, Time dt, Date dd, Time at, Date ad, string dc, string ac, int, int);

	int getFlightID() const;
	void setDepartureTime(const Time& t);
	Time getDepartureTime() const;
	void setArrivalTime(const Time& t);
	Time getArrivalTime() const;
	void setDepartureDate(const Date& d);
	Date getDepartureDate() const;
	void setArrivalDate(const Date& d);
	Date getArrivalDate() const;
	void addbooking(const Booking&);
	void addemployee(const employee&);
	void print() const;
};
#endif // !FLIGHT_H