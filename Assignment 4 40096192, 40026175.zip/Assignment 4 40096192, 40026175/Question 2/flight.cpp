//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include <iostream>
#include <string>
#include"flight.h"
#include "time.h"
#include "date.h"
using namespace std;


Flight::Flight() {}
Flight::Flight(int id1, Time dt, Date dd, Time at, Date ad, string dc, string ac, int nb, int ne) :
	departureTime(dt), departureDate(dd), arrivalTime(at), arrivalDate(ad) {
	flightID = id1;
	departureCity = dc;
	arrivalCity = ac;
	nbbookings = nb;
	nbemployees = ne;
}


int Flight::getFlightID() const {
	return flightID;
}


void Flight::setDepartureTime(const Time& t) {
	departureTime = t;
}

Time Flight::getDepartureTime() const {
	return departureTime;
}

void Flight::setArrivalTime(const Time& t) {
	arrivalTime = t;
}

Time Flight::getArrivalTime() const {
	return arrivalTime;
}

void Flight::setDepartureDate(const Date& d) {
	departureDate = d;
}
Date Flight::getDepartureDate() const {
	return departureDate;
}

void Flight::setArrivalDate(const Date& d) {
	arrivalDate = d;
}

Date Flight::getArrivalDate() const
{
	return arrivalDate;
}

void Flight::addbooking(const Booking& newb) {

	if (nbbookings < 50)
	{
		b[nbbookings] = newb;
		nbbookings++;

	}
	else if(nbbookings>50)
	{
		cout << "Airplane capacity full, cannot book further passengers" << endl;
	}
}

void Flight::addemployee(const employee& newe) {

	if (nbemployees < 10)
	{
		e[nbemployees] = newe;
		nbemployees++;
	}
	
	else if(nbemployees>10)

	{
		cout << "There are enough employees on this flight" << endl;
	}

}

void Flight::print() const {
	cout << "Flight: " << flightID << endl;
	cout << "Departure Time: ";
	departureTime.print();
	cout << "Departure Date: ";
	departureDate.print();
	cout << "Arrival Time: ";
	arrivalTime.print();
	cout << "Arrival Date: ";
	arrivalDate.print();
}