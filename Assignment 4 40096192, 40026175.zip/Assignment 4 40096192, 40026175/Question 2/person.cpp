//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include "person.h"
#include <iostream> 
#include <string>


using namespace std;

//constructor
Person::Person(string first, string last, string add)
{
	firstName = first;
	lastName = last;
	address = add;
}

void Person::print() const
{
	cout << firstName << " " << lastName << endl;
}

void Person::setName(string first, string last)
{
	firstName = first;
	lastName = last;
}

string Person::getFirstName() const
{
	return firstName;
}

string Person::getLastName() const
{
	return lastName;
}
void Person::setAddress(string add1)
{
	address = add1;
}

string Person::getAddress()	const
{
	return address;
}