//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include <iostream>
#include <string> 
#ifndef PERSON_H
#define PERSON_H


using namespace std;

class Person
{
public:

	Person(string first = "", string last = "", string address = "");
	void print() const;
	void setName(string first, string last);
	void setAddress(string);
	string getFirstName() const;
	string getLastName() const;
	string getAddress() const;


protected:
	string firstName;
	string lastName;
	string address;
};
#endif // !PERSON_H