#include <iostream>
#include "payment.h"


using namespace std;

Payment::Payment(float paya) {

	paya = paymentamount;

}


void Payment::setpayamount(float p) {

	paymentamount = p;

}

float Payment::getpayamount() {
	return paymentamount;
}

Payment::~Payment() {

}

void Payment::paymentDetails() {
	cout << "The amount of " << paymentamount << " dollars was paid by the customer" << endl;
}