#include <iostream>
#include "date.h"
#ifndef CUSTOMER_H
#define CUSTOMER_H

using namespace std;

class Customer {

private:
	string customer_name;
	string driving_license;
	Date birth_date_cust;

public:
	Customer();
	Customer(string, string);
	~Customer();
	void setbirthdate(int d, int m, int y);
	void setcustname(string cname);
	void setlicense(string drlic);
	


};
#endif // !CUSTOMER_H