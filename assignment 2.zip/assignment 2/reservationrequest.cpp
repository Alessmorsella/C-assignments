#include <iostream>
#include "customer.h"
#include "date.h"
#include "vehicle.h"
#include "car.h"
#include"truck.h"
#include "reservationrequest.h"

using namespace std;

ReservationRequest::ReservationRequest() {

	vehicle_type = "";
	resrequestcount = 0;
	resrequestnb = 0;
}

ReservationRequest::ReservationRequest(string vhty, int reqcont, int reqnb) {

	vhty = vehicle_type;
	reqcont = resrequestcount;
	reqnb = resrequestnb;

}
ReservationRequest::~ReservationRequest(){}

void ReservationRequest::setcust(string cname, string drlic, int d, int m, int y) {

	new_customer.setcustname(cname);
	new_customer.setlicense(drlic);
	new_customer.setbirthdate(d, m, y);

}

void ReservationRequest::setstartdate(int d, int m, int y) {

	startdate.set_Date(d, m, y);

}

void ReservationRequest::setresdate(int d, int m, int y) {

	resdate.set_Date(d, m, y);
}
void ReservationRequest::setenddate(int d, int m, int y) {

	enddate.set_Date(d, m, y);
}

void ReservationRequest::setcarcapacity(int capa) {

	capacity.setcapacity(capa);
}


void ReservationRequest::setweightlim(int limit) {

	weight_limit.setweightlimit(limit);
}