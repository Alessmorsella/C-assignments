#include<iostream>
#include<string>
#include"Date.h"
#include"vehicle.h"
#ifndef TRUCK_H
#define TRUCK_H


using namespace std;

class Truck :public Vehicle
{
private: 
	int weight_limit;


public:
	Truck(int limit);

	~Truck();

	Truck();
	void setweightlimit(int);
};
#endif // !TRUCK_H
