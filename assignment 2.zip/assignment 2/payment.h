#include <iostream>
#ifndef PAYMENT_H
#define PAYMENT_H


using namespace std;
class Payment {

private:

	float paymentamount;

public:
	
	Payment(float =0.0);
	~Payment();

	void setpayamount(float);

	float getpayamount();

	void paymentDetails();
};
#endif // !PAYMENT_H