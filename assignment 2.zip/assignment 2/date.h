#include<iostream>
#include<string>
#ifndef DATE_H
#define DATE_H


using namespace std;

class Date
{
	int day;
	int month;
	int year;
public:
	Date()
	{
		day = 0, month = 0, year = 0;
	}
	void set_Date(int d, int m, int y)
	{
		if ((m < 1 || m > 12) || (d < 1 || d > 31) || (y < 1900 || y > 2020))
		{
			cout << "Invalid date" << endl;
		}


		else
		{
			day = d;
			month = m;
			year = y;

		}
	}
	~Date()
	{
	}
	void print()
	{
		cout << day << "," << month << "," << year << endl;
	}
};
#endif // !DATE_H