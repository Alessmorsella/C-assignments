#include <iostream>
#include "car.h"
#include "truck.h"
#include "customer.h"
#include "vehiclerentalcontract.h"
#ifndef FLEETMANAGER_H
#define FLEETMANAGER_H


class Fleetmanager {

private: 
	int carfleet_size;
	int truckfleet_size;
	Car *cars;
	Truck *trucks;
	Customer *customers;
	VehicleRentalContract *vehiclerentalcontracts;
	int nbcars;
	int nbtrucks;
	int nbcust;
	int nbrentalcontr;


public:
	Fleetmanager();
	Fleetmanager(int cfsz, int tfsz);
	Fleetmanager(const Fleetmanager&);
	~Fleetmanager();
	void goodres(const ReservationRequest&);








};


#endif // !FLEETMANAGER_H
