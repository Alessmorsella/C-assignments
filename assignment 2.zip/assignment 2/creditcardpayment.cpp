#include <iostream>
#include <string>
#include "payment.h"
#include "creditcardpayment.h"

using namespace std;

Creditcardpayment::Creditcardpayment()
{
	card_name = "";
	exp_date = "";
	cardnmb = "";
	
}

Creditcardpayment::Creditcardpayment(string cna, string exp, string canb, float paya) :Payment(paya)
{
	cna = card_name;
	exp = exp_date;
	canb = cardnmb;
}

Creditcardpayment::~Creditcardpayment() {


}

void Creditcardpayment::setcardname(string na) {
	na = card_name;
};
void Creditcardpayment::setexpdate(string ex) {
	ex = exp_date;
};
void Creditcardpayment::setcardnb(string nb) {
	nb = cardnmb;
};
string Creditcardpayment::getcardname() {
	return card_name;
};
string Creditcardpayment::getexpdate() {
	return exp_date;

};
string Creditcardpayment::getcardnb() {
	return cardnmb;
};

void Creditcardpayment::printcardpayment() {

	Payment::paymentDetails();
	cout << "using a credit card." << endl;
	cout << "Name on the credit card: " << getcardname() << endl;
	cout << "Credit card expiry date: " << getexpdate() << endl;
	cout << "Credit card number: " << getcardnb() << endl;



}