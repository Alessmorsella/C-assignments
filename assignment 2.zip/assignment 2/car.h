#include<iostream>
#include<string>
#include"Date.h"
#include"vehicle.h"
#ifndef CAR_H
#define CAR_H

using namespace std;

class Car : public Vehicle
{private:

	int passenger_capacity;

public:
	Car();
	Car(int capa);
	void setcapacity(int);
	~Car();

};
#endif // !CAR_H
