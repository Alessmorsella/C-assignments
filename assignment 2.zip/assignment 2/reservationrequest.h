#include <iostream>
#include "customer.h"
#include "date.h"
#include "vehicle.h"
#include "car.h"
#include"truck.h"

using namespace std;

class ReservationRequest {

private:
	Customer new_customer;
	string vehicle_type;
	int resrequestnb;
	int resrequestcount;
	Date resdate;
	Date startdate;
	Date enddate;
	Car capacity;
	Truck weight_limit;

public:
	ReservationRequest();
	ReservationRequest(string, int, int);
	void setcust(string, string, int, int, int);
	void setresdate(int, int, int);
	void setstartdate(int, int, int);
	void setenddate(int, int, int);
	void setcarcapacity(int);
	void setweightlim(int);
	~ReservationRequest();


	   	  
};