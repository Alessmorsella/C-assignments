#include <iostream>
#include <string>
#include "date.h"
#ifndef VEHICLE_H
#define VEHICLE_H

using namespace std;

class Vehicle {

private:

	string vehicle_model;
	Date date_of_vehicle;
	int mileage;
	string vehicle_id;
	bool availabillity[12][30];

public:
	Vehicle();
	Vehicle(string, string, int);
	~Vehicle();
	void  set_availibillity(int, int, int);
	bool get_availabillity(int, int);
	void printVehicle();

	
};
#endif // !VEHICLE_H
