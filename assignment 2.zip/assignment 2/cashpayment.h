#include <iostream>
#include "payment.h"
#ifndef CASHPAYMENT_H
#define CASHPAYMENT_H


using namespace std;

class Cashpayment : public Payment {

public:
	Cashpayment(float=0.0);
	void printcash();







};
#endif // !CASHPAYMENT_H