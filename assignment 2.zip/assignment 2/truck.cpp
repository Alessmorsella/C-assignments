#include<iostream>
#include "vehicle.h"
#include "truck.h"

Truck::Truck() {

	weight_limit = 0;
}
Truck::Truck(int limit) {
	
		weight_limit = limit;
	

}

Truck::~Truck() {


}

void Truck::setweightlimit(int limit) {

	limit = weight_limit;

}