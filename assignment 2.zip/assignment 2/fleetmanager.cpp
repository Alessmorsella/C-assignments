#include <iostream>
#include "car.h"
#include "truck.h"
#include "customer.h"
#include "vehiclerentalcontract.h"
#include "fleetmanager.h"
#include "reservationrequest.h"

using namespace std;

Fleetmanager::Fleetmanager() {

	carfleet_size = 0;
	truckfleet_size = 0;
	cars = new Car[20];
	trucks = new Truck[10];
	customers = new Customer[5];
	vehiclerentalcontracts = new VehicleRentalContract[5];
	nbcars = 0;
	nbrentalcontr = 0;
	nbtrucks = 0;
	nbcust = 0;

}

Fleetmanager::Fleetmanager(int cfsz, int tfsz) {

	cfsz = carfleet_size;
	tfsz = truckfleet_size;
	cars = new Car[20];
	trucks = new Truck[10];
	customers = new Customer[5];
	vehiclerentalcontracts = new VehicleRentalContract[5];
	nbcars = 0;
	nbrentalcontr = 0;
	nbtrucks = 0;
	nbcust = 0;

}

Fleetmanager::Fleetmanager(const Fleetmanager& anotherFleetmanager) {
	carfleet_size = anotherFleetmanager.carfleet_size;
	truckfleet_size = anotherFleetmanager.truckfleet_size;
	cars = new Car[20];
	trucks = new Truck[10];
	customers = new Customer[5];
	vehiclerentalcontracts = new VehicleRentalContract[5];
	nbcars = anotherFleetmanager.nbcars;
	nbrentalcontr = anotherFleetmanager.nbrentalcontr;
	nbtrucks = anotherFleetmanager.nbtrucks;
	nbcust = anotherFleetmanager.nbcust;
	for (int i = 0; i < nbcars; i++)
	{
		cars[i] = anotherFleetmanager.cars[i];
	}
	for (int i = 0; i < nbtrucks; i++)
	{
		trucks[i] = anotherFleetmanager.trucks[i];
	}
	for (int i = 0; i < nbrentalcontr; i++)
	{
		vehiclerentalcontracts[i] = anotherFleetmanager.vehiclerentalcontracts[i];
	}
	for (int i = 0; i < nbcust; i++)
	{
		customers[i] = anotherFleetmanager.customers[i];
	}
}
Fleetmanager::~Fleetmanager(){
	delete[] cars;
	delete[] trucks;
	delete[] vehiclerentalcontracts;
	delete[] customers;
}


void Fleetmanager::goodres(const ReservationRequest& r) {

	if (nbre)


}

