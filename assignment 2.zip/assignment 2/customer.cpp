#include <iostream>
#include "customer.h"

using namespace std;

Customer::Customer() {

	customer_name = "";
	driving_license = "";
}
Customer::Customer(string cname, string drlic) {

	cname = customer_name;
	drlic = driving_license;

}

Customer::~Customer(){}

void Customer::setbirthdate(int d, int m, int y) {

	birth_date_cust.set_Date(d, m, y);

}

void Customer::setcustname(string cname) {
	cname = customer_name;

}

void Customer::setlicense(string drlic) {

	drlic = driving_license;
}