#include <iostream>
#include"payment.h"
#ifndef CREDITCARDPAYMENT_H
#define CREDITCARDPAYMENT_H


using namespace std;

class Creditcardpayment :public Payment {


private:
	string card_name;
	string exp_date;
	string cardnmb;

public:
	Creditcardpayment();
	Creditcardpayment(string cna, string exp, string canb, float paya);
	~Creditcardpayment();
	void setcardname(string);
	void setexpdate(string);
	void setcardnb(string);
	string getcardname();
	string getexpdate();
	string getcardnb();
	void printcardpayment();
};
#endif // !CREDITCARDPAYMENT_H