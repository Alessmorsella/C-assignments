#include <iostream>
#include "car.h"
#include "vehicle.h"

using namespace std;

Car::Car(){
	passenger_capacity = 0;

}

Car::Car(int capa){

	passenger_capacity = capa;

}

Car::~Car(){}

void Car::setcapacity(int capa) {

	capa = passenger_capacity;
}