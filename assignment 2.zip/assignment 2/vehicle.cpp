#include <iostream>
#include "date.h"
#include "vehicle.h"
using namespace std;


Vehicle::Vehicle() {
	vehicle_model = "";
	mileage = 0;
	vehicle_id = "";
	availabillity[12][30] = false;

}

Vehicle::Vehicle(string mod, string vid, int mil) {

	mod = vehicle_model;
	vid = vehicle_id;
	mil = mileage;

}

Vehicle::~Vehicle(){}

