#include <iostream>
#include "reservationrequest.h"
#include "cashpayment.h"
#include "creditcardpayment.h"
#ifndef RESERVATIONREQUEST_H
#define RESERVATIONREQUEST_H


using namespace std;

class VehicleRentalContract {

private:
	ReservationRequest res_request;
	Car *rescar;
	Truck *restruck;
	Cashpayment *cashpay;
	Creditcardpayment *credpay;
	bool pickup;

public:
	VehicleRentalContract();






};
#endif // !RESERVATIONREQUEST_H