#include <iostream>
#include "payment.h"
#include "cashpayment.h"
using namespace std;

Cashpayment::Cashpayment(float paya) :Payment(paya) 
{


}

void Cashpayment::printcash()
{
	Payment::paymentDetails();
	cout << " in cash." << endl;


}