//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include "passenger.h"
#include <iostream>
using namespace std;

passenger::passenger() {
	frequentFlyPlan = "";

}


string passenger::getFrequenFlyPlan() const
{
	return frequentFlyPlan;
}

 passenger::passenger(string fre)
{
	frequentFlyPlan = fre;
	
}

passenger::~passenger()
{
}

