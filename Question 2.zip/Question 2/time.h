//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include <iostream>
#ifndef TIME_H
#define TIME_H

using namespace std;

class Time {
private:
	int hour;
	int minute;
	int second;

public:
	Time() { hour = 0; minute = 0; second = 0; }
	Time(int h, int m, int s) {
		hour = (h >= 0 && h < 24) ? h : 0;
		minute = (m >= 0 && m < 60) ? m : 0;
		second = (s >= 0 && s < 60) ? s : 0;
	}

	void setTime(int h, int m, int s) {
		hour = (h >= 0 && h < 24) ? h : 0;
		minute = (m >= 0 && m < 60) ? m : 0;
		second = (s >= 0 && s < 60) ? s : 0;
	}

	void print() const
	{
		cout << hour << ":" << minute << ":" << second << endl;
	}
};
#endif // !1