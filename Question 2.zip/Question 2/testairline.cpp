//Alessandro Morsella 40096192
//Gechen Ma 40026175
#include<iostream>
#include "booking.h"
#include "date.h"
#include "employee.h"
#include "flight.h"
#include "passenger.h"
#include "person.h"
#include "time.h"

using namespace std;

int main() {

	Flight f1(12334, Time(3, 34, 12), Date(1, 3, 2019), Time(6, 23, 45), Date(2, 3, 2019), "Montreal", "Vancouver", 50, 10);
	Flight f2(12323, Time(2, 12, 42), Date(1, 3, 2019), Time(4, 12, 34), Date(1, 3, 2019), "Montreal", "Toronto", 50, 10);
	passenger p1("1245");
	p1.setName("Adam", "Smith");
	p1.setAddress("1234 St catherine");
	passenger p2("1435");
	p2.setName("John", "Johnson");
	p2.setAddress("1212 St catherine");
	passenger p3("1145");
	p3.setName("Conrad", "Conrad");
	p3.setAddress("1653 St catherine");
	passenger p4("1764");
	p4.setName("Mike", "Fox");
	p4.setAddress("1984 St catherine");
	passenger p5("6534");
	p5.setName("Jake", "Glover");
	p5.setAddress("1534 St catherine");
	employee e1("Steward");
	e1.setName("Dean", "Sterling");
	e1.setAddress("3244 Guy");
	employee e2("Pilot");
	e2.setName("Wayne", "Walker");
	e2.setAddress("1232 Guy");
	employee e3("Co-Pilot");
	e3.setName("Phil", "Kane");
	e3.setAddress("4213 Guy");
	Booking b1(p1, "1");
	Booking b2(p2, "2");
	Booking b3(p3, "3");
	Booking b4(p4, "4");
	Booking b5(p5, "5");

	f1.addemployee(e1);
	f1.addemployee(e2);
	f1.addemployee(e3);
	f1.addbooking(b1);
	f1.addbooking(b2);
	f1.addbooking(b3);
	f1.addbooking(b4); 
	f1.addbooking(b5);

	f1.print();
	p1.print();
	e1.print();
	

	system("pause");
	return 0;
}