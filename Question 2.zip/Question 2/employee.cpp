#include "employee.h"


employee::employee()
{
	jobfunction = "";
}


employee::~employee()
{
}

employee::employee(string job)
{
	jobfunction = job;
}


string employee::getJobfunction()
{
	return jobfunction;
}